# howork

## Demo version, not published in webstore yet!

Chrome extension to check and log the times how many you really work (like stopwatch).

This app is to know how exactly know I work in a day and in days.

Simple start stopwatch and stop, reset or save.

And get the records.

